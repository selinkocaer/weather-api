#import requests

#url = "https://api.openweathermap.org/data/2.5/weather?q=London,uk&APPID=dab242ad9fc0b35faf63f05cd408b4b5"

#response = requests.get(url).json()

#print(response)

